#ifndef TECPLOT_TECPLOTMINORREV_H
#define TECPLOT_TECPLOTMINORREV_H

/*
 * Repository revision number - auto-generated; do not edit.
 */
#define TecplotMinorRev 61060
#endif
