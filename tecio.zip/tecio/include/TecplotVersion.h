#pragma once


/*
 * Some consumers of this version information need integers representing the
 * individual parts of the version string. Other consumers want a single string
 * with everything already in it. To support both of these use cases, we define
 * each version component individually then use a preprocessor trick to combine
 * those individual components into a single version string. See
 * http://stackoverflow.com/questions/240353/convert-a-preprocessor-token-to-a-string
 * for details on the preprocessor trick.
 */
#define TP_STRINGIZE2(s) #s
#define TP_STRINGIZE(s) TP_STRINGIZE2(s)

#define TecplotMajorVer            15
#define TecplotMinorVer            2
#define TecplotMajorRev            0
#define TecplotReleaseYear         2015
#define TecplotReleaseMonth        05   // Must include a leading zero for single-digit values (see request #29649)
#include "TecplotMinorRev.h"

/*
 * NOTE: If you change TecplotBinarySDKVersion, you MUST also:
 *
 * 1. Update preplot:
 *    - Change this define symbol in preplot.cpp
 *    - Change version number in the data file format in the comments in preplot.cpp
 *    - Change the version number of Preplot itself in preplot.cpp
 * 2. Maintain the ability to write the old plt file format:
 *    - Add a new entry to BinaryFileVersion_e
 *    - Add a concrete class of the VersionWriterInterface, and update
 *      VersionWriterAbstractFactory to return the correct instance for the previous and
 *      new BinaryFileVersion_e
 *    - Abstract away the difference in the two versions behind an interface (if one does
 *      not yet exist) and create concrete implementations that can write the old and the
 *      new versions. For a trivial example of this, see FileTypeWriterInterface and its
 *      associated factory and concrete classes.
 */
#define TecplotSDKBinaryFileVersion     112 /* NOTE: only change this when we change the binary file format */

#define TecplotAPIVersion               141    /* ...updated when the macro or TecUtil language changes or introduces new functionality and is most often a conjunction of TecplotMajorVer and TecplotMinorVer numbers but may vary */

#define TecplotMajorVerStr         TP_STRINGIZE(TecplotMajorVer)
#define TecplotMinorVerStr         TP_STRINGIZE(TecplotMinorVer)
#define TecplotMajorRevStr         TP_STRINGIZE(TecplotMajorRev)
#define TecplotMinorRevStr         TP_STRINGIZE(TecplotMinorRev)

#define TecplotLicenseVersionStr   TP_STRINGIZE(TecplotReleaseYear) "." TP_STRINGIZE(TecplotReleaseMonth)
#define TecplotAPIVersionStr       TP_STRINGIZE(TecplotAPIVersion)

#define TecVersionId TecplotMajorVerStr "." TecplotMinorVerStr "." TecplotMajorRevStr "." TecplotMinorRevStr
#define TecCopyright "Copyright (c) 1988-2015 Tecplot, Inc."
#define TecCurrentYear "2015"

