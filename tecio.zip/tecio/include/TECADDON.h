#pragma once

#include "TecUtil.h"
#include "TECGUI.h"
